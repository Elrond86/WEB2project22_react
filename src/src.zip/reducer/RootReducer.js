import React from 'react';
import ReactDOM from 'react-dom/client';
import logger from '../../config/winston'


const 

/** im Reducer kommen nun die Actions an, die in der Reducer-Funtion jetzt verabeitet werden. */
function rootReducer(state = initialState, action) {
    logger.debug("Bin im Reducer: " + action.type)
    initialState = {
        user: null,     //das wird später der user, wenn ich mich eingelogt habe
        loginPending: false,    //Ladeanzeige, während etwas passiert, damit Benutzer sieht, dass er gerade läd
        showLoginDialog: false, //das is des, was vorher im Widged war. Kommt jetzt in den Zentralen store
    }
    return state;
};
export default rootReducer;



import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  value: 0,
}

export const counterSlice = createSlice({
  name: 'counter',
  initialState = {
    user: null,     //das wird später der user, wenn ich mich eingelogt habe
    loginPending: false,    //Ladeanzeige, während etwas passiert, damit Benutzer sieht, dass er gerade läd
    showLoginDialog: false, //das is des, was vorher im Widged war. Kommt jetzt in den Zentralen store
},
  reducers: {
    increment: (state) => {
      // Redux Toolkit allows us to write "mutating" logic in reducers. It
      // doesn't actually mutate the state because it uses the Immer library,
      // which detects changes to a "draft state" and produces a brand new
      // immutable state based off those changes
      state.value += 1
    },
    decrement: (state) => {
      state.value -= 1
    },
    incrementByAmount: (state, action) => {
      state.value += action.payload
    },
  },
})

// Action creators are generated for each case reducer function
export const { increment, decrement, incrementByAmount } = counterSlice.actions

export default counterSlice.reducer